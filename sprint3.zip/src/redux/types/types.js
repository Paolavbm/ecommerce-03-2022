export const types = {
    login: 'login',
    logout: 'logout',
    register: 'register'
}

export const typesProducts = {
    agregar: 'Agregar',
    list: 'List',
    // delete: 'Delete',
    search: 'search'
}

export const typesCarrito = {
    añadir: 'añadir',
    listar: 'listar',
    remover: 'remover',
    // vaciar: 'vaciar',
    editar: 'editar',
    // clear: 'clear'
}
