import AgregarProducto from "../components/AgregarProducto";
import DetalleProducto from "../components/DetalleProducto";
import Footer from "../components/Footer";
import Header from "../components/Header";
import Inicio from "../components/Inicio";
import List from "../components/List";
import Registro from "../components/Registro";


function App() {
  return (
    <div className="App">

<List/>
<Footer/>
    </div>
  );
}

export default App;
